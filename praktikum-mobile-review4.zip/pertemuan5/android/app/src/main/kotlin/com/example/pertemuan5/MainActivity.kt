package com.example.pertemuan5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
